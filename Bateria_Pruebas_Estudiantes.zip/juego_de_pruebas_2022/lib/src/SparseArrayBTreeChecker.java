package es.uned.lsi.eped.pract2021_2022;

public class SparseArrayBTreeChecker<E> extends SparseArrayBTree<E> {
	public SparseArrayBTreeChecker() {
		super();
	}
	
	public int getSize() {
		return btree.size();
	}
	
}
