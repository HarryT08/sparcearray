package es.uned.lsi.eped.pract2021_2022;

import ...

public class SparseArraySequence<E>  extends ...  implements SparseArrayIF<E> {

	protected ... sequence;
	
	public SparseArraySequence() {
		...
	}
	
	...
}
